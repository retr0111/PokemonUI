This is an API requesting app that is able to identify some Pokemon,
and is able list different types of berries and Pokemon
